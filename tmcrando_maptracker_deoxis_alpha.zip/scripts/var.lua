ScriptItemSpec="scripts/item_spec/"
ScriptSettings="scripts/settings/"
ScriptLogic="scripts/logic/"
ScriptMain="scripts/main/"
ScriptAutotracking="scripts/autotracking/"

JsLayouts="layouts/"
JsItems="items/"
JsMap="maps/"


ScriptLocations="scripts/locations/"
JsLocations="locations/"