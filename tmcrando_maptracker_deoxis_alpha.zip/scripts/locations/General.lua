
function Json_General_Fuzer_Fuzer()
  if Json_General_Fuzer_Fuzer1()==1 then
    return 1
  else
    return 0
  end
end


Tracker:AddLocations(JsLocations.."General.json")