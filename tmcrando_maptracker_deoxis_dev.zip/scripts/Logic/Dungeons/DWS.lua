function DwsEnter()
    if (has("jabber") or has("flippers")) and (has("sword") or has("bombs") or has("lights") or has("lamp") or has("ocarina")) then
        return 1
    else
        return 0
    end
end
