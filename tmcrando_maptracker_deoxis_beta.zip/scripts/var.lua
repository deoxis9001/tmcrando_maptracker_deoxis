ScriptItemSpec="scripts/item_spec/"
ScriptSettings="scripts/settings/"
ScriptLogic="scripts/logic/"
ScriptMain="scripts/main/"
ScriptAutotracking="scripts/autotracking/"

JsLayouts="layouts/"
JsItems="items/"
JsMap="maps/"


ScriptLocations="scripts/locations/"
JsLocations="locations/"
F ="Fusion/"
FO ="FusionObscure/"
FOR ="FusionObscureRupee/"
FR ="FusionRupee/"
N ="Normal/"
O ="Obscure/"
OR ="ObscureRupee/"
R ="Rupee/"

-- 	"access_rules":["$RV_N_Check,[$RV_N_Check_Y]","{$RV_N_Check_B}"],
