ScriptHost:LoadScript("scripts/var.lua")

ScriptHost:LoadScript(ScriptItemSpec.."init.lua")
ScriptHost:LoadScript(ScriptSettings.."init.lua")
ScriptHost:LoadScript(ScriptLogic.."init.lua")
ScriptHost:LoadScript(ScriptMain.."init.lua")
ScriptHost:LoadScript(ScriptAutotracking.."init.lua")