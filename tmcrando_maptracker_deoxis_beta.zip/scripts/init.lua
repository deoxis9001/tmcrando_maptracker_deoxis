
ScriptHost:LoadScript("scripts/item_spec/init.lua")
ScriptHost:LoadScript("scripts/settings/init.lua")
ScriptHost:LoadScript("scripts/logic/init.lua")
ScriptHost:LoadScript("scripts/main/init.lua")
ScriptHost:LoadScript("scripts/autotracking/init.lua")