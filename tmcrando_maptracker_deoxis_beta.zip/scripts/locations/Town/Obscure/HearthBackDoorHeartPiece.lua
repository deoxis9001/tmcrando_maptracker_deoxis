function Town_O_HearthBackDoorHeartPiece_HearthBackDoorHeartPiece()
  if Town_Inn_BackdoorHP()==1 then
    return 1
  else
    return 0
  end
end
function Town_O_HearthBackDoorHeartPiece_HearthBackDoorHeartPiece_Y()
  if Town_Inn_BackdoorHP()==1 then
    return 1
  else
    return 0
  end
end
function Town_O_HearthBackDoorHeartPiece_HearthBackDoorHeartPiece_B()
  if Town_Inn_BackdoorHP()==1 then
    return 1
  else
    return 0
  end
end
function Town_O_HearthBackDoorHeartPiece_HearthRightPot()
  if Town_Inn_Pot()==1 then
    return 1
  else
    return 0
  end
end
function Town_O_HearthBackDoorHeartPiece_HearthRightPot_Y()
  if Town_Inn_Pot()==1 then
    return 1
  else
    return 0
  end
end
function Town_O_HearthBackDoorHeartPiece_HearthRightPot_B()
  if Town_Inn_Pot()==1 then
    return 1
  else
    return 0
  end
end