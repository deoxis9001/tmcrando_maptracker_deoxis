function Town_N_DrLeftHouse_DrLeftHouse()
  if Town_DrLeft_AtticItem()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_DrLeftHouse_DrLeftHouse_Y()
  if Town_DrLeft_AtticItem()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_DrLeftHouse_DrLeftHouse_B()
  if Town_DrLeft_AtticItem()==1 then
    return 1
  else
    return 0
  end
end