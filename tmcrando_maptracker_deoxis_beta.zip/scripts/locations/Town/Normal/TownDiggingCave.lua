function Town_N_TownDiggingCave_CaveChests()
  if Town_Digging()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_TownDiggingCave_CaveChests_Y()
  if Town_Digging()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_TownDiggingCave_CaveChests_B()
  if Town_Digging()==1 then
    return 1
  else
    return 0
  end
end

function Town_N_TownDiggingCave_TownBasementLeft()
  if Town_Well_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_TownDiggingCave_TownBasementLeft_Y()
  if Town_Well_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_TownDiggingCave_TownBasementLeft_B()
  if Town_Well_LeftChest()==1 then
    return 1
  else
    return 0
  end
end