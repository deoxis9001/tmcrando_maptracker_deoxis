function Town_N_BakeryAtticChest()
  if Town_Bakery_AtticChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_BakeryAtticChest_Y()
  if Town_Bakery_AtticChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_BakeryAtticChest_B()
  if Town_Bakery_AtticChest()==1 then
    return 1
  else
    return 0
  end
end