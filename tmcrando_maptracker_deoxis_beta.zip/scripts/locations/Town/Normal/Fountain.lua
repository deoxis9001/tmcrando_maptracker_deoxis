function Town_N_Fountain_Mulldozers()
  if Town_Fountain_BigChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Fountain_Mulldozers_Y()
  if Town_Fountain_BigChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Fountain_Mulldozers_B()
  if Town_Fountain_BigChest()==1 then
    return 1
  else
    return 0
  end
end

function Town_N_Fountain_SmallChest()
  if Town_Fountain_SmallChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Fountain_SmallChest_Y()
  if Town_Fountain_SmallChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Fountain_SmallChest_B()
  if Town_Fountain_SmallChest()==1 then
    return 1
  else
    return 0
  end
end

function Town_N_Fountain_HeartPiece()
  if Town_Fountain_HP()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Fountain_HeartPiece_Y()
  if Town_Fountain_HP()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Fountain_HeartPiece_B()
  if Fountain()==1 then
    return 1
  else
    return 0
  end
end

