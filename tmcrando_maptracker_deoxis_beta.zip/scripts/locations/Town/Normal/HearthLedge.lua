function Town_N_HearthLedge_HearthLedge()
  if Town_Inn_LedgeChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HearthLedge_HearthLedge_Y()
  if Town_Inn_LedgeChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HearthLedge_HearthLedge_B()
  if Town_Inn_LedgeChest()==1 then
    return 1
  else
    return 0
  end
end