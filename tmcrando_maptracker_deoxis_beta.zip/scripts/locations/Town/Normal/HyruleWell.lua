function Town_N_HyruleWell_HyruleWellBottomChest()
  if Town_Well_BottomChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HyruleWell_HyruleWellBottomChest_Y()
  if Town_Well_BottomChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HyruleWell_HyruleWellBottomChest_B()
  if Town_Well_BottomChest()==1 then
    return 1
  else
    return 0
  end
end

function Town_N_HyruleWell_HyruleWellCenterChest()
  if Town_Well_PillarChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HyruleWell_HyruleWellCenterChest_Y()
  if Town_Well_PillarChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HyruleWell_HyruleWellCenterChest_B()
  if Town_Well_PillarChest()==1 then
    return 1
  else
    return 0
  end
end

