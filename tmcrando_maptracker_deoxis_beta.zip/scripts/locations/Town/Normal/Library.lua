function Town_N_Library_YellowLibraryMinish()
  if Town_Library_YellowMinish_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Library_YellowLibraryMinish_Y()
  if Town_Library_YellowMinish_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Library_YellowLibraryMinish_B()
  if Town_Library_YellowMinish_NPC()==1 then
    return 1
  else
    return 0
  end
end