function Town_N_LadyNexttoCafe_LadyNexttoCafe()
  if Town_CafeLady_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_LadyNexttoCafe_LadyNexttoCafe_Y()
  if Town_CafeLady_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_LadyNexttoCafe_LadyNexttoCafe_B()
  if Town_CafeLady_NPC()==1 then
    return 1
  else
    return 0
  end
end