function Town_N_Bell_Bell()
  if Town_Bell_HP()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Bell_Bell_Y()
  if Town_Bell_HP()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Bell_Bell_B()
  if Town_Bell_HP()==1 then
    return 1
  else
    return 0
  end
end