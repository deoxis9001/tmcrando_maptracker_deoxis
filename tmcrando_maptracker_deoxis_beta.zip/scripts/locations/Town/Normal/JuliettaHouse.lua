function Town_N_JuliettaHouse()
  if Town_Jullieta_Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_JuliettaHouse_Y()
  if Town_Jullieta_Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_JuliettaHouse_B()
    return 1
end