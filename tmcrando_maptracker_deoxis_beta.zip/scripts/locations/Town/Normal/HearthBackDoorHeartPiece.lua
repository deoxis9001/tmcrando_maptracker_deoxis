function Town_N_HearthBackDoorHeartPiece_HearthBackDoorHeartPiece()
  if Town_Inn_BackdoorHP()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HearthBackDoorHeartPiece_HearthBackDoorHeartPiece_Y()
  if Town_Inn_BackdoorHP()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_HearthBackDoorHeartPiece_HearthBackDoorHeartPiece_B()
  if Town_Inn_BackdoorHP()==1 then
    return 1
  else
    return 0
  end
end