function Town_N_StockwellShop_WalletSpot()
  if Town_Shop_80Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_WalletSpot_Y()
  if Town_Shop_80Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_WalletSpot_B()
    return 1
end

function Town_N_StockwellShop_BoomerangSpot()
  if Town_Shop_300Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_BoomerangSpot_Y()
  if Town_Shop_300Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_BoomerangSpot_B()
    return 1
end

function Town_N_StockwellShop_QuiverSpot()
  if Town_Shop_600Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_QuiverSpot_Y()
  if Town_Shop_600Item()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_QuiverSpot_B()
    return 1
end

function Town_N_StockwellShop_AtticChest()
  if Town_Shop_AtticChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_AtticChest_Y()
  if Town_Shop_AtticChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_AtticChest_B()
  if Town_Shop_AtticChest()==1 then
    return 1
  else
    return 0
  end
end

function Town_N_StockwellShop_DogFoodBottleSpot()
  if Town_Shop_BehindCounterItem()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_DogFoodBottleSpot_Y()
  if Town_Shop_BehindCounterItem()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_StockwellShop_DogFoodBottleSpot_B()
    return 1
end