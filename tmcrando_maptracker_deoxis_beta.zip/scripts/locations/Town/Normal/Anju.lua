function Town_N_Anju_HeartPiece()
  if Town_Cuccos_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Anju_HeartPiece_Y()
  if Town_Cuccos_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Anju_HeartPiece_B()
  if Town_Cuccos_NPC()==1 then
    return 1
  else
    return 0
  end
end