function Town_N_Carlov()
  if Town_Carlov_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Carlov_Y()
  if Town_Carlov_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_Carlov_B()
  if Town_Carlov_NPC()==1 then
    return 1
  else
    return 0
  end
end