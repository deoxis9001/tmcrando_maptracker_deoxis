function Town_N_School_RoofChest()
  if Town_School_Roof_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_School_RoofChest_Y()
  if Town_School_Roof_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_School_RoofChest_B()
  if Town_School_Roof_Chest()==1 then
    return 1
  else
    return 0
  end
end

function Town_N_School_PulltheStatue()
  if Town_Well_TopChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_School_PulltheStatue_Y()
  if Town_Well_TopChest()==1 then
    return 1
  else
    return 0
  end
end
function Town_N_School_PulltheStatue_B()
  if Town_Well_TopChest()==1 then
    return 1
  else
    return 0
  end
end

