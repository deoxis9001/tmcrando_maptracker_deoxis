function Town_N_SwiftbladeDojo_SpinAttack()
  if (Town_Dojo_NPC1()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_SpinAttack_Y()
  if (Town_Dojo_NPC1()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_SpinAttack_B()
  if (Town_Dojo_NPC1()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_RockBreaker()
  if (Town_Dojo_NPC2()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_RockBreaker_Y()
  if (Town_Dojo_NPC2()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_RockBreaker_B()
  if (Town_Dojo_NPC2()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_DashAttack()
  if (Town_Dojo_NPC3()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_DashAttack_Y()
  if (Town_Dojo_NPC3()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_DashAttack_B()
  if (Town_Dojo_NPC3()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_DownThrust()
  if (Town_Dojo_NPC4()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_DownThrust_Y()
  if (Town_Dojo_NPC4()==1) then
    return 1
  else
    return 0
  end
end
function Town_N_SwiftbladeDojo_DownThrust_B()
  if (Town_Dojo_NPC4()==1) then
    return 1
  else
    return 0
  end
end