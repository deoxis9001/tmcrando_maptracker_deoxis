function Town_N_FlippersCave_ScissorBeetles()
  if Town_UnderLibrary_BigChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_N_FlippersCave_ScissorBeetles_Y()
  if Town_UnderLibrary_BigChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_N_FlippersCave_ScissorBeetles_B()
  if Town_UnderLibrary_BigChest()==1  then
    return 1
  else
    return 0
  end
end

function Town_N_FlippersCave_FrozenChest()
  if Town_UnderLibrary_FrozenChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_N_FlippersCave_FrozenChest_Y()
  if Town_UnderLibrary_FrozenChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_N_FlippersCave_FrozenChest_B()
  if Town_UnderLibrary_FrozenChest()==1  then
    return 1
  else
    return 0
  end
end