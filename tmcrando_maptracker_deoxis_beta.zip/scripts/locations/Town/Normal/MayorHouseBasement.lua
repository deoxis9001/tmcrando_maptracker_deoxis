function Town_N_MayorHouseBasement_MayorHouseBasement()
  if Town_Well_RightChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_N_MayorHouseBasement_MayorHouseBasement_Y()
  if Town_Well_RightChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_N_MayorHouseBasement_MayorHouseBasement_B()
  if Town_Well_RightChest()==1  then
    return 1
  else
    return 0
  end
end