function Town_F_TownWaterfall_Waterfall()
  if Town_WaterfallFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Town_F_TownWaterfall_Waterfall_Y()
  if Town_WaterfallFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Town_F_TownWaterfall_Waterfall_B()
  if Town_WaterfallFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end