DirWorld="Town/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."TownWaterfall.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."TownWaterfall.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."SchoolGardensOpen.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."SchoolGardensOpen.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Anju.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Anju.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."BakeryAtticChest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."BakeryAtticChest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Bell.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Bell.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Carlov.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Carlov.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."DrLeftHouse.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."DrLeftHouse.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."EasternShops.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."EasternShops.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."FlippersCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."FlippersCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Fountain.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Fountain.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."HearthBackDoorHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."HearthBackDoorHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."HearthLedge.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."HearthLedge.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."HyruleWell.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."HyruleWell.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."JuliettaHouse.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."JuliettaHouse.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."LadyNexttoCafe.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."LadyNexttoCafe.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Library.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Library.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."MayorHouseBasement.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."MayorHouseBasement.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."School.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."School.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."SchoolGardens.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."SchoolGardens.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."StockwellShop.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."StockwellShop.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."SwiftbladeDojo.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."SwiftbladeDojo.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."TownDiggingCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."TownDiggingCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. O .."HearthBackDoorHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. O .."HearthBackDoorHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. OR .."FlippersCaveRupees.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. OR .."FlippersCaveRupees.json")