function Town_OR_FlippersCaveRupees_ScissorBeetles()
  if Town_UnderLibrary_BigChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_OR_FlippersCaveRupees_ScissorBeetles_Y()
  if Town_UnderLibrary_BigChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_OR_FlippersCaveRupees_ScissorBeetles_B()
  if Town_UnderLibrary_BigChest()==1  then
    return 1
  else
    return 0
  end
end

function Town_OR_FlippersCaveRupees_FrozenChest()
  if Town_UnderLibrary_FrozenChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_OR_FlippersCaveRupees_FrozenChest_Y()
  if Town_UnderLibrary_FrozenChest()==1  then
    return 1
  else
    return 0
  end
end
function Town_OR_FlippersCaveRupees_FrozenChest_B()
  if Town_UnderLibrary_FrozenChest()==1  then
    return 1
  else
    return 0
  end
end

function Town_OR_FlippersCaveRupees_UndertheWaterfall()
  if Town_UnderLibrary_Underwater()==1  then
    return 1
  else
    return 0
  end
end
function Town_OR_FlippersCaveRupees_UndertheWaterfall_Y()
  if Town_UnderLibrary_Underwater()==1  then
    return 1
  else
    return 0
  end
end
function Town_OR_FlippersCaveRupees_UndertheWaterfall_B()
  if Town_UnderLibrary_Underwater()==1  then
    return 1
  else
    return 0
  end
end


