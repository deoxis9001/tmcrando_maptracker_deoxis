function N_FOR_Test()
  if N_FOR_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_FOR_Test_Y()
  if N_FOR_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_FOR_Test_B()
  if N_FOR_Test()==1 then
    return 1
  else
    return 0
  end
end