function N_FR_Test()
  if N_FR_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_FR_Test_Y()
  if N_FR_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_FR_Test_B()
  if N_FR_Test()==1 then
    return 1
  else
    return 0
  end
end