function N_O_Test()
  if N_O_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_O_Test_Y()
  if N_O_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_O_Test_B()
  if N_O_Test()==1 then
    return 1
  else
    return 0
  end
end