function N_F_Test()
  if N_F_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_F_Test_Y()
  if N_F_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_F_Test_B()
  if N_F_Test()==1 then
    return 1
  else
    return 0
  end
end