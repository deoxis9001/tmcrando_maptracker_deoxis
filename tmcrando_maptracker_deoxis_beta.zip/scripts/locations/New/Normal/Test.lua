function N_N_Test()
  if N_N_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_N_Test_Y()
  if N_N_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_N_Test_B()
  if N_N_Test()==1 then
    return 1
  else
    return 0
  end
end