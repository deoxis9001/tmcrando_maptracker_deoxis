DirWorld="new/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. FO .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. FO .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. FOR .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. FOR .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. FR .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. FR .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. O .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. O .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. OR .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. OR .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. R .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. R .."test.json")
