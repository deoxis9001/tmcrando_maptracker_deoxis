function N_FO_Test()
  if N_FO_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_FO_Test_Y()
  if N_FO_Test()==1 then
    return 1
  else
    return 0
  end
end
function N_FO_Test_B()
  if N_FO_Test()==1 then
    return 1
  else
    return 0
  end
end