function MinishWoods_F_MinishVillage_Barrel()
  if MinishVillage_BarrelHouse_Item()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_MinishVillage_Barrel_Y()
  if MinishVillage_BarrelHouse_Item()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_MinishVillage_Barrel_B()
  if MinishVillage_BarrelHouse_Item()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_F_MinishVillage_DockHeartPiece()
  if MinishVillage_HP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_MinishVillage_DockHeartPiece_Y()
  if MinishVillage_HP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_MinishVillage_DockHeartPiece_B()
  if MinishVillage_HP()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_F_MinishVillage_MinishPathChest()
  if MinishWoods_MinishPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_MinishVillage_MinishPathChest_Y()
  if MinishWoods_MinishPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_MinishVillage_MinishPathChest_B()
  if MinishWoods_MinishPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end

