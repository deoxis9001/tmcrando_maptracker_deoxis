function MinishWoods_F_CrossthePond_Chest()
  if MinishWoods_NorthFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_CrossthePond_Chest_Y()
  if MinishWoods_NorthFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_CrossthePond_Chest_B()
  if MinishWoods_NorthFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end