function MinishWoods_F_GoldenOcto_KillOcto()
  if MinishWoods_RopeGolden_KillRope()==1 or MinishWoods_RopeGolden_KillRope()==2 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_GoldenOcto_KillOcto_Y()
  if MinishWoods_RopeGolden_KillRope()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_GoldenOcto_KillOcto_B()
  if MinishWoods_RopeGolden_KillRope()==1 then
    return 1
  else
    return 0
  end
end