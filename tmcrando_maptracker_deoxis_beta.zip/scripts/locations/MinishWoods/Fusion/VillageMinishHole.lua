function MinishWoods_F_VillageMinishHole_MinishHole()
  if MinishWoods_MinishPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_VillageMinishHole_MinishHole_Y()
  if MinishWoods_MinishPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_VillageMinishHole_MinishHole_B()
  if MinishWoods_MinishPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end