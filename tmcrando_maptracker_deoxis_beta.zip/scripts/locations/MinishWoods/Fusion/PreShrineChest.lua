function MinishWoods_F_PreShrineChest_Chest()
  if MinishWoods_SouthFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_PreShrineChest_Chest_Y()
  if MinishWoods_SouthFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_PreShrineChest_Chest_B()
  if MinishWoods_SouthFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end