function MinishWoods_F_PostMinishVillageChest_WindCrestChest()
  if MinishWoods_PostVillageFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_PostMinishVillageChest_WindCrestChest_Y()
  if MinishWoods_PostVillageFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_PostMinishVillageChest_WindCrestChest_B()
  if MinishWoods_PostVillageFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end