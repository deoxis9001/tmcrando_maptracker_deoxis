function MinishWood_F_EntranceChest_Chest()
  if MinishWoods_WestFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWood_F_EntranceChest_Chest_Y()
  if MinishWoods_WestFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWood_F_EntranceChest_Chest_B()
  if MinishWoods_WestFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end