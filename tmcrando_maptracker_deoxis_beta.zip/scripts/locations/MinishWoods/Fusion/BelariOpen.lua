function MinishWoods_F_BelariOpen_1stItem()
  if MinishWoods_BombMinish_NPC1()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_BelariOpen_1stItem_Y()
  if MinishWoods_BombMinish_NPC1()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_BelariOpen_1stItem_B()
  if MinishWoods_BombMinish_NPC1()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_F_BelariOpen_2ndItem()
  if MinishWoods_BombMinish_NPC2()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_BelariOpen_2ndItem_Y()
  if MinishWoods_BombMinish_NPC2()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_F_BelariOpen_2ndItem_B()
  if MinishWoods_BombMinish_NPC2()==1 then
    return 1
  else
    return 0
  end
end

