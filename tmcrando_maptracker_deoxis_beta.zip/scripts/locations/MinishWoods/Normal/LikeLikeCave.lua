function MinishWoods_N_LikeLikeCave_LeftChest()
  if MinishWoods_LikeLikeDiggingCave_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_LikeLikeCave_LeftChest_Y()
  if MinishWoods_LikeLikeDiggingCave_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_LikeLikeCave_LeftChest_B()
  if MinishWoods_LikeLikeDiggingCave_LeftChest()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_N_LikeLikeCave_RightChest()
  if MinishWoods_LikeLikeDiggingCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_LikeLikeCave_RightChest_Y()
  if MinishWoods_LikeLikeDiggingCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_LikeLikeCave_RightChest_B()
  if MinishWoods_LikeLikeDiggingCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end

