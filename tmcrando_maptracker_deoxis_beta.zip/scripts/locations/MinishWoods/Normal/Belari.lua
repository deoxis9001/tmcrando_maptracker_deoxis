function MinishWoods_N_Belari_Belari()
  if MinishWoods_BombMinish_NPC1()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_Belari_Belari_Y()
  if MinishWoods_BombMinish_NPC1()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_Belari_Belari_B()
  if MinishWoods_BombMinish_NPC1()==1 then
    return 1
  else
    return 0
  end
end