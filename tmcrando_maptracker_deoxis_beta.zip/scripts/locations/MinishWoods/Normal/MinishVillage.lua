function MinishWoods_N_MinishVillage_Barrel()
  if MinishVillage_BarrelHouse_Item()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishVillage_Barrel_Y()
  if MinishVillage_BarrelHouse_Item()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishVillage_Barrel_B()
  if MinishVillage_BarrelHouse_Item()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_N_MinishVillage_DockHeartPiece()
  if MinishVillage_HP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishVillage_DockHeartPiece_Y()
  if MinishVillage_HP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishVillage_DockHeartPiece_B()
  if MinishVillage_HP()==1 then
    return 1
  else
    return 0
  end
end

