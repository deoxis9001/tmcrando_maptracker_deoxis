function MinishWoods_N_SyrupsHut_WitchsItem()
  if MinishWoods_WitchHut_Item()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_SyrupsHut_WitchsItem_Y()
  if MinishWoods_WitchHut_Item()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_SyrupsHut_WitchsItem_B()
  if MinishWoods_WitchHut_Item()==1 then
    return 1
  else
    return 0
  end
end