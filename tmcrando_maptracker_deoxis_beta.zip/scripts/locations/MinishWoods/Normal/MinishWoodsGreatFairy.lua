function MinishWood_N_MinishWoodsGreatFairy_GreatFairy()
  if MinishWoods_GreatFairy_NPC()==1 then
    return 1
  else
    return 0
  end
end
function MinishWood_N_MinishWoodsGreatFairy_GreatFairy_Y()
  if MinishWoods_GreatFairy_NPC()==1 then
    return 1
  else
    return 0
  end
end
function MinishWood_N_MinishWoodsGreatFairy_GreatFairy_B()
  if MinishWoods_GreatFairy_NPC()==1 then
    return 1
  else
    return 0
  end
end