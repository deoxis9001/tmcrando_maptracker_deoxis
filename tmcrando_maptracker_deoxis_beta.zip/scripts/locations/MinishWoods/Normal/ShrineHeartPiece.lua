function MinishWoods_N_ShrineHeartPiece_HeartPiece()
  if MinishWoods_BottomHP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_ShrineHeartPiece_HeartPiece_Y()
  if MinishWoods_BottomHP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_ShrineHeartPiece_HeartPiece_B()
  if MinishWoods_BottomHP()==1 then
    return 1
  else
    return 0
  end
end