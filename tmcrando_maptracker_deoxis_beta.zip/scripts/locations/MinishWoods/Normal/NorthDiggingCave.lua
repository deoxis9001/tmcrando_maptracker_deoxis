function MinishWoods_N_NorthDiggingCave_DiggingCave()
  if WitchDiggingCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_NorthDiggingCave_DiggingCave_Y()
  if WitchDiggingCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_NorthDiggingCave_DiggingCave_B()
  if WitchDiggingCave_Chest()==1 then
    return 1
  else
    return 0
  end
end