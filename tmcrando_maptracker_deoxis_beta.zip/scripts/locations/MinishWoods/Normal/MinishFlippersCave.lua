function MinishWoods_N_MinishFlippersCave_LeftChest()
  if MinishWoods_FlipperHole_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_LeftChest_Y()
  if MinishWoods_FlipperHole_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_LeftChest_B()
  if MinishWoods_FlipperHole_LeftChest()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_N_MinishFlippersCave_LeftHeartPiece()
  if MinishWoods_FlipperHole_HP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_LeftHeartPiece_Y()
  if MinishWoods_FlipperHole_HP()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_LeftHeartPiece_B()
  if MinishWoods_FlipperHole_HP()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_N_MinishFlippersCave_MiddleChest()
  if MinishWoods_FlipperHole_MiddleChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_MiddleChest_Y()
  if MinishWoods_FlipperHole_MiddleChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_MiddleChest_B()
  if MinishWoods_FlipperHole_MiddleChest()==1 then
    return 1
  else
    return 0
  end
end

function MinishWoods_N_MinishFlippersCave_RightChest()
  if MinishWoods_FlipperHole_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_RightChest_Y()
  if MinishWoods_FlipperHole_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function MinishWoods_N_MinishFlippersCave_RightChest_B()
  if MinishWoods_FlipperHole_RightChest()==1 then
    return 1
  else
    return 0
  end
end


