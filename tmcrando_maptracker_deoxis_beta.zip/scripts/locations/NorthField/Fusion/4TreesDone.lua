function NorthField_F_4TreesDone_CenterLadder()
  if NorthField_TreeFusion_CenterBigChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_4TreesDone_CenterLadder_Y()
  if NorthField_TreeFusion_CenterBigChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_4TreesDone_CenterLadder_B()
  if NorthField_TreeFusion_CenterBigChest()==1 then
    return 1
  else
    return 0
  end
end