function NorthField_F_TopRightTree_TopRightTree()
  if NorthField_TreeFusion_TopRightChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_TopRightTree_TopRightTree_Y()
  if NorthField_TreeFusion_TopRightChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_TopRightTree_TopRightTree_B()
  if NorthField_TreeFusion_TopRightChest()==1 then
    return 1
  else
    return 0
  end
end