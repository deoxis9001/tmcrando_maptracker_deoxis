function NorthField_F_Waterfall_Greatblade()
  if NorthField_WaterfallFusion_DojoNPC()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_Waterfall_Greatblade_Y()
  if NorthField_WaterfallFusion_DojoNPC()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_Waterfall_Greatblade_B()
  if NorthField_WaterfallFusion_DojoNPC()==1 then
    return 1
  else
    return 0
  end
end