function NorthField_F_TopLeftTree_TopLeftTree()
  if NorthField_TreeFusion_TopLeftChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_TopLeftTree_TopLeftTree_Y()
  if NorthField_TreeFusion_TopLeftChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_TopLeftTree_TopLeftTree_B()
  if NorthField_TreeFusion_TopLeftChest()==1 then
    return 1
  else
    return 0
  end
end