function NorthField_F_BottomRightTree_BottomRightTree()
  if NorthField_TreeFusion_BottomRightChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_BottomRightTree_BottomRightTree_Y()
  if NorthField_TreeFusion_BottomRightChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_BottomRightTree_BottomRightTree_B()
  if NorthField_TreeFusion_BottomRightChest()==1 then
    return 1
  else
    return 0
  end
end