function NorthField_F_BottomLeftTree_BottomLeftTree()
  if NorthField_TreeFusion_BottomLeftChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_BottomLeftTree_BottomLeftTree_Y()
  if NorthField_TreeFusion_BottomLeftChest()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_F_BottomLeftTree_BottomLeftTree_B()
  if NorthField_TreeFusion_BottomLeftChest()==1 then
    return 1
  else
    return 0
  end
end