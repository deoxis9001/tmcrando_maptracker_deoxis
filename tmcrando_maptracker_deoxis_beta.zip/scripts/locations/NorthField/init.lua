DirWorld="NorthField/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."BottomLeftTree.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."BottomLeftTree.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."BottomRightTree.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."BottomRightTree.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."TopLeftTree.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."TopLeftTree.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."TopRightTree.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."TopRightTree.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."Waterfall.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."Waterfall.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."4TreesDone.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."4TreesDone.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."CaveHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."CaveHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. O .."DiggingSpot.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. O .."DiggingSpot.json")

