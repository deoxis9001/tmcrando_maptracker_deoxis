function NorthField_O_DiggingSpot_DiggingSpot()
  if NorthField_DigSpot()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_O_DiggingSpot_DiggingSpot_Y()
  if NorthField_DigSpot()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_O_DiggingSpot_DiggingSpot_B()
  if NorthField_DigSpot()==1 then
    return 1
  else
    return 0
  end
end