function NorthField_N_CaveHeartPiece_HeartPiece()
  if NorthField_HP()==1 or NorthField_HP()==2 then
    return 1
  else
    return 0
  end
end
function NorthField_N_CaveHeartPiece_HeartPiece_Y()
  if NorthField_HP()==1 then
    return 1
  else
    return 0
  end
end
function NorthField_N_CaveHeartPiece_HeartPiece_B()
  if NorthField_HP()==1 then
    return 1
  else
    return 0
  end
end