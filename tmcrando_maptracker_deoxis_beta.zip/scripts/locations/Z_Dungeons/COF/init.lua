DirDungeons="new/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. F .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. F .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. FO .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. FO .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. FOR .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. FOR .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. FR .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. FR .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. N .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. N .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. O .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. O .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. OR .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. OR .."test.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..DirDungeons.."".. R .."test.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..DirDungeons.."".. R .."test.json")
