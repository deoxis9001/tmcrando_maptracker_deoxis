DirWorld="dungeons/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."COF/init.lua")
ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."DHC/init.lua")
ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."DWS/init.lua")
ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."FOW/init.lua")
ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."POW/init.lua")
ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."RC/init.lua")
ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."TOD/init.lua")