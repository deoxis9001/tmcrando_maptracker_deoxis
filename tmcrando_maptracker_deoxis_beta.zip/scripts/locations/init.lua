
ScriptHost:LoadScript(ScriptLocations.."SouthHyruleField/init.lua")
ScriptHost:LoadScript(ScriptLocations.."Town/init.lua")
ScriptHost:LoadScript(ScriptLocations.."NorthField/init.lua")
ScriptHost:LoadScript(ScriptLocations.."Castle/init.lua")
ScriptHost:LoadScript(ScriptLocations.."Hills/init.lua")
ScriptHost:LoadScript(ScriptLocations.."LonLon/init.lua")
ScriptHost:LoadScript(ScriptLocations.."FallsLower/init.lua")
ScriptHost:LoadScript(ScriptLocations.."Hylia/init.lua")
ScriptHost:LoadScript(ScriptLocations.."MinishWoods/init.lua")
ScriptHost:LoadScript(ScriptLocations.."Trilby/init.lua")

