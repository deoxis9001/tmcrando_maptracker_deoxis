function Hylia_N_HyliaCapeHeartPiece_CapeHeartPiece()
  if Hylia_SmallIsland_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_HyliaCapeHeartPiece_CapeHeartPiece_Y()
  if Hylia_SmallIsland_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_HyliaCapeHeartPiece_CapeHeartPiece_B()
  if Hylia_SmallIsland_HP()==3 or Hylia_SmallIsland_HP()==1 then
    return 1
  else
    return 0
  end
end