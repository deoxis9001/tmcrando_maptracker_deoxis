function Hylia_N_Waveblade_Waveblade()
  if Hylia_Dojo_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_Waveblade_Waveblade_Y()
  if Hylia_Dojo_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_Waveblade_Waveblade_B()
  if Hylia_Dojo_NPC()==1 then
    return 1
  else
    return 0
  end
end


function Hylia_N_Waveblade_HeartPiece()
  if Hylia_Dojo_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_Waveblade_HeartPiece_Y()
  if Hylia_Dojo_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_Waveblade_HeartPiece_B()
  if Hylia_Dojo_HP()==1 then
    return 1
  else
    return 0
  end
end