function Hylia_N_LonLonNorthHeartPiece_HeartPiece()
  if Hylia_CapeCave_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_LonLonNorthHeartPiece_HeartPiece_Y()
  if Hylia_CapeCave_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_LonLonNorthHeartPiece_HeartPiece_B()
  if Hylia_CapeCave_HP()==1 then
    return 1
  else
    return 0
  end
end