function Hylia_N_NorthMinishHole_NorthMinishHole()
  if Hylia_NorthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_NorthMinishHole_NorthMinishHole_Y()
  if Hylia_NorthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_NorthMinishHole_NorthMinishHole_B()
  if Hylia_NorthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end