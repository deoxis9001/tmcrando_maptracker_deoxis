function Hylia_N_NorthHyliaCapeCave_NorthHyliaCapeCave()
  if Hylia_NorthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_NorthHyliaCapeCave_NorthHyliaCapeCave_Y()
  if Hylia_NorthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_NorthHyliaCapeCave_NorthHyliaCapeCave_B()
  if Hylia_NorthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end