function Hylia_N_PondHeartPiece_DivingforLove()
  if Hylia_SunkenHP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_PondHeartPiece_DivingforLove_Y()
  if Hylia_SunkenHP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_PondHeartPiece_DivingforLove_B()
  if Hylia_SunkenHP()==1 then
    return 1
  else
    return 0
  end
end