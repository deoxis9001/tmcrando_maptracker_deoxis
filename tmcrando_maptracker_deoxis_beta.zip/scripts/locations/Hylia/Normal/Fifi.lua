function Hylia_N_Fifi_Fifi()
  if Hylia_DogNPC()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_Fifi_Fifi_Y()
  if Hylia_DogNPC()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_Fifi_Fifi_B()
  if Hylia_DogNPC()==1 then
    return 1
  else
    return 0
  end
end