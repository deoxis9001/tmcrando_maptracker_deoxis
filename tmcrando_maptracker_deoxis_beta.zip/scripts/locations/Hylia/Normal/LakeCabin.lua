function Hylia_N_LakeCabin_LakeCabin()
  if Hylia_MayorCabin_Item()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_LakeCabin_LakeCabin_Y()
  if Hylia_MayorCabin_Item()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_LakeCabin_LakeCabin_B()
  if Hylia_MayorCabin_Item()==1 then
    return 1
  else
    return 0
  end
end