function Hylia_N_HyliaSouthernHeartPiece_HeartPiece()
  if Hylia_BottomHP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_HyliaSouthernHeartPiece_HeartPiece_Y()
  if Hylia_BottomHP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_HyliaSouthernHeartPiece_HeartPiece_B()
  if Hylia_BottomHP()==1 then
    return 1
  else
    return 0
  end
end