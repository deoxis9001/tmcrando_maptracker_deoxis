function Hylia_N_MinishWoodsNorthMinishHole_MinishWoodsNorthMinishHole()
  if Hylia_SouthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_MinishWoodsNorthMinishHole_MinishWoodsNorthMinishHole_Y()
  if Hylia_SouthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_N_MinishWoodsNorthMinishHole_MinishWoodsNorthMinishHole_B()
  if Hylia_SouthMinishHole_Chest()==1 then
    return 1
  else
    return 0
  end
end