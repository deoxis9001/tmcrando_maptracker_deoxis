function Hylia_F_Librari_Librari()
  if Hylia_CrackFusion_LibrariNPC()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_Librari_Librari_Y()
  if Hylia_CrackFusion_LibrariNPC()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_Librari_Librari_B()
  if Hylia_CrackFusion_LibrariNPC()==1 then
    return 1
  else
    return 0
  end
end