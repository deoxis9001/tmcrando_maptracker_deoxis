function Hylia_F_MiddleoftheLake_DiggingCave()
  if Hylia_MiddleIslandFusion_DigCaveChest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_MiddleoftheLake_DiggingCave_Y()
  if Hylia_MiddleIslandFusion_DigCaveChest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_MiddleoftheLake_DiggingCave_B()
  if Hylia_MiddleIslandFusion_DigCaveChest()==1 then
    return 1
  else
    return 0
  end
end