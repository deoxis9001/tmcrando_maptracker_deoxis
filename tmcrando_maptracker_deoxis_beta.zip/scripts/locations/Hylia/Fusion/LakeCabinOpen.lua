function Hylia_F_LakeCabinOpen_LakeCabin()
  if Hylia_MayorCabin_Item()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_LakeCabinOpen_LakeCabin_Y()
  if Hylia_MayorCabin_Item()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_LakeCabinOpen_LakeCabin_B()
  if Hylia_MayorCabin_Item()==1 then
    return 1
  else
    return 0
  end
end

function Hylia_F_LakeCabinOpen_Chest()
  if Hylia_CabinPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_LakeCabinOpen_Chest_Y()
  if Hylia_CabinPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_LakeCabinOpen_Chest_B()
  if Hylia_CabinPathFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end

