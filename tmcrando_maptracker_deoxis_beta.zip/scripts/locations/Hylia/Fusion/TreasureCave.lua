function Hylia_F_TreasureCave_TreasureCave()
  if Hylia_CapeCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_TreasureCave_TreasureCave_Y()
  if Hylia_CapeCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_TreasureCave_TreasureCave_B()
  if Hylia_CapeCave_Chest()==1 then
    return 1
  else
    return 0
  end
end


function Hylia_F_TreasureCave_Beanstalk()
  if Hylia_BeanstalkFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_TreasureCave_Beanstalk_Y()
  if Hylia_BeanstalkFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_TreasureCave_Beanstalk_B()
  if Hylia_BeanstalkFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end


function Hylia_F_TreasureCave_BeanstalkHeartPiece()
  if Hylia_BeanstalkFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_TreasureCave_BeanstalkHeartPiece_Y()
  if Hylia_BeanstalkFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hylia_F_TreasureCave_BeanstalkHeartPiece_B()
  if Hylia_BeanstalkFusion_HP()==1 then
    return 1
  else
    return 0
  end
end


