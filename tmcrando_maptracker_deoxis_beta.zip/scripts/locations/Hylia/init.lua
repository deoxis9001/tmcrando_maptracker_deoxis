DirWorld="Hylia/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."LakeCabinOpen.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."LakeCabinOpen.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."Librari.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."Librari.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."MiddleoftheLake.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."MiddleoftheLake.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."TreasureCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."TreasureCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Fifi.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Fifi.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."HyliaCapeHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."HyliaCapeHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."HyliaSouthernHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."HyliaSouthernHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."LakeCabin.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."LakeCabin.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."LonLonNorthHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."LonLonNorthHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."MinishWoodsNorthMinishHole.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."MinishWoodsNorthMinishHole.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."NorthHyliaCapeCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."NorthHyliaCapeCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."NorthMinishHole.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."NorthMinishHole.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."PondHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."PondHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Waveblade.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Waveblade.json")