function LonLon_O_LonLonRanchDiggingSpot_DiggingSpotAboveTree()
  if LonLon_DigSpot()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_O_LonLonRanchDiggingSpot_DiggingSpotAboveTree_Y()
  if LonLon_DigSpot()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_O_LonLonRanchDiggingSpot_DiggingSpotAboveTree_B()
  if LonLon_DigSpot()==1 then
    return 1
  else
    return 0
  end
end