function LonLon_F_GoronQuest_SmallChest()
  if LonLon_GoronCaveFusion_SmallChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_GoronQuest_SmallChest_Y()
  if LonLon_GoronCaveFusion_SmallChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_GoronQuest_SmallChest_B()
  if LonLon_GoronCaveFusion_SmallChest()==1 then
    return 1
  else
    return 0
  end
end

function LonLon_F_GoronQuest_BigChest()
  if LonLon_GoronCaveFusion_BigChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_GoronQuest_BigChest_Y()
  if LonLon_GoronCaveFusion_BigChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_GoronQuest_BigChest_B()
  if LonLon_GoronCaveFusion_BigChest()==1 then
    return 1
  else
    return 0
  end
end