function LonLon_F_LonLonDriedUpPond_LonLonPond()
  if LonLon_PuddleFusion_BigChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_LonLonDriedUpPond_LonLonPond_Y()
  if LonLon_PuddleFusion_BigChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_LonLonDriedUpPond_LonLonPond_B()
  if LonLon_PuddleFusion_BigChest()==1 then
    return 1
  else
    return 0
  end
end