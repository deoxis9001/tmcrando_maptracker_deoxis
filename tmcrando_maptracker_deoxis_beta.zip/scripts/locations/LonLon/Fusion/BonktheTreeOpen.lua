function LonLon_F_BonktheTreeOpen_MinishPathChest()
  if LonLon_Path_FusionChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_BonktheTreeOpen_MinishPathChest_Y()
  if LonLon_Path_FusionChest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_BonktheTreeOpen_MinishPathChest_B()
  if LonLon_Path_FusionChest()==1 then
    return 1
  else
    return 0
  end
end

function LonLon_F_BonktheTreeOpen_MinishHeartPiece()
  if LonLon_Path_HP()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_BonktheTreeOpen_MinishHeartPiece_Y()
  if LonLon_Path_HP()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_F_BonktheTreeOpen_MinishHeartPiece_B()
  if LonLon_Path_HP()==1 then
    return 1
  else
    return 0
  end
end

