function LonLon_N_MalonPot_MalonPot()
  if LonLon_RanchPot()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_MalonPot_MalonPot_Y()
  if LonLon_RanchPot()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_MalonPot_MalonPot_B()
  if LonLon_RanchPot()==1 then
    return 1
  else
    return 0
  end
end