function LonLon_N_BonktheTree_MinishPathHeartPiece()
  if LonLon_Path_HP()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_BonktheTree_MinishPathHeartPiece_Y()
  if LonLon_Path_HP()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_BonktheTree_MinishPathHeartPiece_B()
  if LonLon_Path_HP()==1 then
    return 1
  else
    return 0
  end
end