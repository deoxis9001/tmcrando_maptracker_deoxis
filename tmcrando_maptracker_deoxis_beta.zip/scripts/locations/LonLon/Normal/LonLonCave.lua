function LonLon_N_LonLonCave_LonLonCave()
  if LonLon_Cave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_LonLonCave_LonLonCave_Y()
  if LonLon_Cave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_LonLonCave_LonLonCave_B()
  if LonLon_Cave_Chest()==1 then
    return 1
  else
    return 0
  end
end

function LonLon_N_LonLonCave_HiddenBombWall()
  if LonLon_CaveSecret_Chest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_LonLonCave_HiddenBombWall_Y()
  if LonLon_CaveSecret_Chest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_LonLonCave_HiddenBombWall_B()
  if LonLon_CaveSecret_Chest()==1 then
    return 1
  else
    return 0
  end
end
