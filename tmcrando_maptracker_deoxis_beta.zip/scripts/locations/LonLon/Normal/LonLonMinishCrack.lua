function LonLon_N_LonLonMinishCrack_LonLonMinishCrack()
  if LonLon_NorthMinishCrack_Chest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_LonLonMinishCrack_LonLonMinishCrack_Y()
  if LonLon_NorthMinishCrack_Chest()==1 then
    return 1
  else
    return 0
  end
end
function LonLon_N_LonLonMinishCrack_LonLonMinishCrack_B()
  if LonLon_NorthMinishCrack_Chest()==1 then
    return 1
  else
    return 0
  end
end