DirWorld="LonLon/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."BonktheTreeOpen.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."BonktheTreeOpen.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."GoronQuest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."GoronQuest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."LonLonDriedUpPond.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."LonLonDriedUpPond.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."BonktheTree.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."BonktheTree.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."LonLonCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."LonLonCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."LonLonMinishCrack.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."LonLonMinishCrack.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."MalonPot.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."MalonPot.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. O .."LonLonRanchDiggingSpot.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. O .."LonLonRanchDiggingSpot.json")