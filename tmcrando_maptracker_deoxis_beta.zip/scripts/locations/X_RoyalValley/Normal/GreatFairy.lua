function RV_N_GreatFairy()
  if Sword4()==1 and has("bombs") and has("spinattack") then
    return 1
  else
    return 0
  end
end
function RV_N_GreatFairy_Y()
  if Sword4()==1 and has("bombs") and has("spinattack") then
    return 1
  else
    return 0
  end
end
function RV_N_GreatFairy_B()
  if Sword4()==1 and has("bombs") and has("spinattack") then
    return 1
  else
    return 0
  end
end