DirWorld="RoyalValley/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..N.."GreatFairy.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..N.."GreatFairy.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..N.."LostWoodsSecretChest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..N.."LostWoodsSecretChest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..N.."Dampe.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..N.."Dampe.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..N.."NorthwestGrave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..N.."NorthwestGrave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..F.."NorthwestGraveFusion.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..F.."NorthwestGraveFusion.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..F.."NortheastGraveFusion.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..F.."NortheastGraveFusion.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld..""..F.."JoyButterfly.lua")
Tracker:AddLocations(JsLocations..""..DirWorld..""..F.."JoyButterfly.json")
