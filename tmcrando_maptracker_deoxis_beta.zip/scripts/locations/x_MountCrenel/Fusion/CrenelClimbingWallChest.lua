function MC_F_CrenelClimbingWallChest()
  if (has("boots") or MC_F_CrenelClimbingWallChest_Y()==1) and has("bottle") and has("grip") then
    return 1
  else
    return 0
  end
end
function MC_F_CrenelClimbingWallChest_Y()
  if (MC_ACCESS_BASE_Y()==1 and (has("grip")) then
    return 1
  else
    return 0
  end
end
function MC_F_CrenelClimbingWallChest_B()
  if (MC_ACCESS_BASE_Y()==1 and (has("grip")) then
    return 1
  else
    return 0
  end
end
