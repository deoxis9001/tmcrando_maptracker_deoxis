function MC_F_MiddleCrenelTektiteGolden()
  if CanDamageOff()==1 and (has("boots") or MC_F_MiddleCrenelTektiteGolden_Y()==1) and has("bottle") and (has("bombs") or has("grip")) then
    return 1
  else
    return 0
  end
end
function MC_F_MiddleCrenelTektiteGolden_Y()
  if CanDamage()==1 and (MC_ACCESS_BASE_Y()==1 and (has("bombs") or has("grip")) then
    return 1
  else
    return 0
  end
end
function MC_F_MiddleCrenelTektiteGolden_B()
  if CanDamage()==1 and (MC_ACCESS_BASE_Y()==1 and (has("bombs") or has("grip")) then
    return 1
  else
    return 0
  end
end
