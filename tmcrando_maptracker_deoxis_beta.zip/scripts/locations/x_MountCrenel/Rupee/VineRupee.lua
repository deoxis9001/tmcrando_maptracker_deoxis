function MC_R_VineRupee()
  if has("boots") or MC_R_VineRupee_Y()==1 then
    return 1
  else
    return 0
  end
end
function MC_R_VineRupee_Y()
  if ((Sword1()==1 and has("spinattack")) or has("cape") or has("flippers")) then
    return 1
  else
    return 0
  end
end
function MC_R_VineRupee_B()
  if has("boots") then
    return 1
  else
    return 0
  end
end