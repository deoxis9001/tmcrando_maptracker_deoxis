function MC_N_BridgeCave()
    if (has("boots") or MC_N_BridgeCave_Y()==1) and has("bottle") and (has("bombs") or has("grip")) then
    return 1
  else
    return 0
  end
end
function MC_N_BridgeCave_Y()
  if (MC_ACCESS_BASE_Y()==1 and (has("bombs") or has("grip")) then
    return 1
  else
    return 0
  end
end
function MC_N_BridgeCave_B()
  if (MC_ACCESS_BASE_Y()==1 and (has("bombs") or has("grip")) then
    return 1
  else
    return 0
  end
end