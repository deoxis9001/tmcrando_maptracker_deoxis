function MC_N_CrenelWallFairy()
  if( has("boots") or MC_N_CrenelWallFairy_Y()==1) and has("bottle") and has("bombs") and has("grip") then
    return 1
  else
    return 0
  end
end
function MC_N_CrenelWallFairy_Y()
  if (MC_ACCESS_BASE_Y()==1 and has("bombs") and has("grip")  then
    return 1
  else
    return 0
  end
end
function MC_N_CrenelWallFairy_B()
  if (MC_ACCESS_BASE_Y()==1 and has("bombs") and has("grip")  then
    return 1
  else
    return 0
  end
end