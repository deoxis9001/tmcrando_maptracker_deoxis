function MC_N_FairyCaveHeartPiece()
  if( has("boots") or MC_N_FairyCaveHeartPiece_Y()==1) and has("bottle") and has("bombs") then
    return 1
  else
    return 0
  end
end
function MC_N_FairyCaveHeartPiece_Y()
  if (MC_ACCESS_BASE_Y()==1 and has("bombs") then
    return 1
  else
    return 0
  end
end
function MC_N_FairyCaveHeartPiece_B()
  if (MC_ACCESS_BASE_Y()==1 and has("bombs") then
    return 1
  else
    return 0
  end
end