function MC_N_Melari()
  if( has("boots") or MC_N_BusinessScrub_Y()==1) and has("bottle") and ( has("grip") and ( ( has("gust") and ( has("bombs") or has("bow") or has("boomerang") or Beam()== 1 ) ) or has("cape") or has("lights") ) or has("cane") ) then    
	 return 1
  else
    return 0
  end
end
function MC_N_Melari_Y()
  if (MC_ACCESS_BASE_Y()==1 and ( has("grip") and ( ( has("gust") and ( has("bombs") or has("bow") or has("boomerang") or Beam()== 1 ) ) or has("cape") or has("lights") ) or has("cane") ) then
	return 1
  else
    return 0
  end
end
function MC_N_Melari_B()
  if (MC_ACCESS_BASE_Y()==1 and ( has("grip") and ( ( has("gust") and ( has("bombs") or has("bow") or has("boomerang") or Beam()== 1 ) ) or has("cape") or has("lights") ) or has("cane") ) then
    return 1
  else
    return 0
  end
end