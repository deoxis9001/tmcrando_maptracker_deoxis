DirWorld="MountCrenel/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."CrenelClimbingWallChest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."CrenelClimbingWallChest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."MiddleCrenelTektiteGolden.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."MiddleCrenelTektiteGolden.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."BridgeCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."BridgeCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."BusinessScrub.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."BusinessScrub.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."CrenelWallFairy.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."CrenelWallFairy.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."CrenelMineCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."CrenelMineCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."FairyCaveHeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."FairyCaveHeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Melari.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Melari.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. R .."VineRupee.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. R .."VineRupee.json")


-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."test.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."test.json")

-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. FO .."test.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. FO .."test.json")

-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. FOR .."test.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. FOR .."test.json")

-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. FR .."test.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. FR .."test.json")

-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."test.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."test.json")

-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. O .."test.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. O .."test.json")

-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. OR .."test.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. OR .."test.json")

-- ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. R .."VineRupee.lua")
-- Tracker:AddLocations(JsLocations..""..DirWorld.."".. R .."VineRupee.json")
