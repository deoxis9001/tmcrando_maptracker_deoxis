function N_FR_Test()
  if Sword4()==1 and (has("bombs") or has("flippers") or has("cape")) and has("spinattack") then
    return 1
  else
    return 0
  end
end
function N_FR_Test_Y()
  if N_FR_Test()==1 and has("lamp") then
    return 1
  else
    return 0
  end
end
function N_FR_Test_B()
  if Sword4()==1 and (has("bombs") or has("flippers") or has("cape")) and has("spinattack") then
    return 1
  else
    return 0
  end
end