function N_O_Test()
  if Sword4()==1 and (has("bombs") or has("flippers") or has("cape")) and has("spinattack") then
    return 1
  else
    return 0
  end
end
function N_O_Test_Y()
  if N_O_Test()==1 and has("lamp") then
    return 1
  else
    return 0
  end
end
function N_O_Test_B()
  if Sword4()==1 and (has("bombs") or has("flippers") or has("cape")) and has("spinattack") then
    return 1
  else
    return 0
  end
end