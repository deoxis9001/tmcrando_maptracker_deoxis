
function Castle_F_RopeGolden_KillRope()
  if Castle_RopeGolden_KillRope()==2 or Castle_RopeGolden_KillRope()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_RopeGolden_KillRope_Y()
  if Castle_RopeGolden_KillRope()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_RopeGolden_KillRope_B()
  if Castle_RopeGolden_KillRope()==1 then
    return 0
  else
    return 0
  end
end