function Castle_F_GardensRightFountain_DryFountain()
  if Castle_RightFountainFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_GardensRightFountain_DryFountain_Y()
  if Castle_RightFountainFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_GardensRightFountain_DryFountain_B()
  if Castle_RightFountainFusion_HP()==1 then
    return 1
  else
    return 0
  end
end

function Castle_F_GardensRightFountain_MinishHole()
  if Castle_RightFountainFusion_MinishHoleChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_GardensRightFountain_MinishHole_Y()
  if Castle_RightFountainFusion_MinishHoleChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_GardensRightFountain_MinishHole_B()
  if Castle_RightFountainFusion_MinishHoleChest()==1 then
    return 1
  else
    return 0
  end
end

