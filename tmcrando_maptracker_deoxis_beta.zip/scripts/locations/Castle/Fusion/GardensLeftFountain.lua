function Castle_F_GardensLeftFountain_MinishHole()
  if Castle_LeftFountainFusion_MinishHoleChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_GardensLeftFountain_MinishHole_Y()
  if Castle_LeftFountainFusion_MinishHoleChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_F_GardensLeftFountain_MinishHole_B()
  if Castle_LeftFountainFusion_MinishHoleChest()==1 then
    return 1
  else
    return 0
  end
end
