DirWorld="Castle/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."GrimbladeDojo.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."GrimbladeDojo.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."RopeGolden.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."RopeGolden.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Moat.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Moat.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."GardensRightFountain.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."GardensRightFountain.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."GardensLeftFountain.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."GardensLeftFountain.json")

