function Castle_N_GrimbladeDojo_Grimblade()
  if Castle_Dojo_NPC()==1 then
    return 1
  else
    return 0
  end
end

function Castle_N_GrimbladeDojo_Grimblade_Y()
  if Castle_Dojo_NPC()==1 then
    return 1
  else
    return 0
  end
end
function Castle_N_GrimbladeDojo_Grimblade_B()
  if Castle_Dojo_NPC()==1 then
    return 1
  else
    return 0
  end
end

function Castle_N_GrimbladeDojo_HeartPiece()
  if Castle_Dojo_HP()==1 then
    return 1
  else
    return 0
  end
end
function Castle_N_GrimbladeDojo_HeartPiece_Y()
  if Castle_Dojo_HP()==1 then
    return 1
  else
    return 0
  end
end
function Castle_N_GrimbladeDojo_HeartPiece_B()
  if Castle_Dojo_HP()==1 then
    return 1
  else
    return 0
  end
end
