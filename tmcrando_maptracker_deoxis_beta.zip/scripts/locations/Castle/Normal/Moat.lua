function Castle_N_Moat_MoatLeft()
  if Castle_Moat_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_N_Moat_MoatLeft_Y()
  if Castle_Moat_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_N_Moat_MoatLeft_B()
  if Castle_Moat_LeftChest()==1 then
    return 1
  else
    return 0
  end
end

function Castle_N_Moat_MoatRight()
  if Castle_Moat_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_N_Moat_MoatRight_Y()
  if Castle_Moat_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function Castle_N_Moat_MoatRight_B()
  if Castle_Moat_RightChest()==1 then
    return 1
  else
    return 0
  end
end


