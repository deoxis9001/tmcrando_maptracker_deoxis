function Hills_N_BombWall_BombWall()
  if Hills_BombCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_N_BombWall_BombWall_Y()
  if Hills_BombCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_N_BombWall_BombWall_B()
  if Hills_BombCave_Chest()==1 then
    return 1
  else
    return 0
  end
end