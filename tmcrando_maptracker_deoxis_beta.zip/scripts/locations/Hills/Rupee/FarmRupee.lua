function Hills_R_FarmRupee_FarmRupee()
  if Hills_FarmDigCave_Item()==1 then
    return 1
  else
    return 0
  end
end
function Hills_R_FarmRupee_FarmRupee_Y()
  if Hills_FarmDigCave_Item()==1 then
    return 1
  else
    return 0
  end
end
function Hills_R_FarmRupee_FarmRupee_B()
  if Hills_FarmDigCave_Item()==1 then
    return 1
  else
    return 0
  end
end