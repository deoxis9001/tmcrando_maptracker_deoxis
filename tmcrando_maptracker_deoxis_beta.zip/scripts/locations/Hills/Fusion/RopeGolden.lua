function Hills_F_RopeGolden_KillRope()
  if Hills_RopeGolden_KillRope()==1 or Hills_RopeGolden_KillRope()==2 then
    return 1
  else
    return 0
  end
end
function Hills_F_RopeGolden_KillRope_Y()
  if Hills_RopeGolden_KillRope()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_RopeGolden_KillRope_B()
  if Hills_RopeGolden_KillRope()==1 then
    return 1
  else
    return 0
  end
end