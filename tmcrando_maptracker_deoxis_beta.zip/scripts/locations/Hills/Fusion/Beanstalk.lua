function Hills_F_Beanstalk_LeftChest()
  if Hills_BeanstalkFusion_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_Beanstalk_LeftChest_Y()
  if Hills_BeanstalkFusion_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_Beanstalk_LeftChest_B()
  if Hills_BeanstalkFusion_LeftChest()==1 then
    return 1
  else
    return 0
  end
end

function Hills_F_Beanstalk_RightChest()
  if Hills_BeanstalkFusion_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_Beanstalk_RightChest_Y()
  if Hills_BeanstalkFusion_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_Beanstalk_RightChest_B()
  if Hills_BeanstalkFusion_RightChest()==1 then
    return 1
  else
    return 0
  end
end

function Hills_F_Beanstalk_HeartPiece()
  if Hills_BeanstalkFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_Beanstalk_HeartPiece_Y()
  if Hills_BeanstalkFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_Beanstalk_HeartPiece_B()
  if Hills_BeanstalkFusion_HP()==1 then
    return 1
  else
    return 0
  end
end

