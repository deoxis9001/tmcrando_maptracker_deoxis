function Hills_F_FarmChest_FarmChest()
  if Hills_Fusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_FarmChest_FarmChest_Y()
  if Hills_Fusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Hills_F_FarmChest_FarmChest_B()
  if Hills_Fusion_Chest()==1 then
    return 1
  else
    return 0
  end
end