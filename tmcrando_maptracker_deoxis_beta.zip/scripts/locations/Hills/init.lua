DirWorld="Hills/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."Beanstalk.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."Beanstalk.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."FarmChest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."FarmChest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."RopeGolden.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."RopeGolden.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."BombableWall.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."BombableWall.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. R .."FarmRupee.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. R .."FarmRupee.json")