function SouthHyruleField_N_Tingle()
  if (SouthField_Tingle_NPC()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_N_Tingle_Y()
  if (SouthField_Tingle_NPC()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_N_Tingle_B()
  if (SouthField_Tingle_NPC()==1) then
    return 1
  else
    return 0
  end
end