function SouthHyruleField_N_MinishFlippersHole()
  if ( SouthField_MinishSize_WaterHole_HP()==1 ) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_N_MinishFlippersHole_Y()
  if ( SouthField_MinishSize_WaterHole_HP()==1 ) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_N_MinishFlippersHole_B()
  if ( SouthField_MinishSize_WaterHole_HP()==1 ) then
    return 1
  else
    return 0
  end
end