function SouthHyruleField_N_SmithsHouse()
  if (Smith_House_Chest()==1 or Smith_Floor_Item1()==1 or Smith_Floor_Item2()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_N_SmithsHouse_Y()
  if (Smith_House_Chest()==1 or Smith_Floor_Item1()==1 or Smith_Floor_Item2()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_N_SmithsHouse_B()
  if (Smith_House_Chest()==1 or Smith_Floor_Item1()==1 or Smith_Floor_Item2()==1) then
    return 1
  else
    return 0
  end
end