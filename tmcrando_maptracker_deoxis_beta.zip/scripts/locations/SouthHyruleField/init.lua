DirWorld="SouthHyruleField/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."SmithsHouse.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."SmithsHouse.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. FR .."RupeeCaveFusion.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. FR .."RupeeCaveFusion.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."NearLinksHouseChestFusion.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."NearLinksHouseChestFusion.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."Tingle.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."Tingle.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."TreeHeartPieceFusion.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."TreeHeartPieceFusion.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."MinishFlippersHole.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."MinishFlippersHole.json")