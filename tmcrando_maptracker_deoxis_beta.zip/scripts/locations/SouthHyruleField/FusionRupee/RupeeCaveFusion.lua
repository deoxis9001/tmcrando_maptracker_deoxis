function SouthHyruleField_FR_RupeeCaveFusion()
	if (SouthField_PuddleFusion_Item()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_FR_RupeeCaveFusion_Y()
	if (SouthField_PuddleFusion_Item()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_FR_RupeeCaveFusion_B()
	if (SouthField_PuddleFusion_Item()==1) then
    return 1
  else
    return 0
  end
end