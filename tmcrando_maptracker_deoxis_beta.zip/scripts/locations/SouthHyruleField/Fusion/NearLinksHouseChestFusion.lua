function SouthHyruleField_F_NearLinksHouseChestFusion()
  if (SouthField_Fusion_Chest()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_F_NearLinksHouseChestFusion_Y()
  if (SouthField_Fusion_Chest()==1) then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_F_NearLinksHouseChestFusion_B()
  if (SouthField_Fusion_Chest()==1) then
    return 1
  else
    return 0
  end
end