function SouthHyruleField_F_TreeHeartPieceFusion()
  if SouthField_TreeFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_F_TreeHeartPieceFusion_Y()
  if SouthField_TreeFusion_HP()==1 then
    return 1
  else
    return 0
  end
end
function SouthHyruleField_F_TreeHeartPieceFusion_B()
  if SouthField_TreeFusion_HP()==1 then
    return 1
  else
    return 0
  end
end