function FallsLower_R_SouthVeilFallsRupees_Rupee1()
  if FallsLower_RockItem1()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_R_SouthVeilFallsRupees_Rupee1_Y()
  if FallsLower_RockItem1()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_R_SouthVeilFallsRupees_Rupee1_B()
  if FallsLower_RockItem1()==1 then
    return 1
  else
    return 0
  end
end

function FallsLower_R_SouthVeilFallsRupees_Rupee2()
  if FallsLower_RockItem2()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_R_SouthVeilFallsRupees_Rupee2_Y()
  if FallsLower_RockItem2()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_R_SouthVeilFallsRupees_Rupee2_B()
  if FallsLower_RockItem2()==1 then
    return 1
  else
    return 0
  end
end

function FallsLower_R_SouthVeilFallsRupees_Rupee3()
  if FallsLower_RockItem3()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_R_SouthVeilFallsRupees_Rupee3_Y()
  if FallsLower_RockItem3()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_R_SouthVeilFallsRupees_Rupee3_B()
  if FallsLower_RockItem3()==1 then
    return 1
  else
    return 0
  end
end

