function FallsLower_N_SouthMittsCave_LeftChest()
  if FallsLower_DigCave_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_N_SouthMittsCave_LeftChest_Y()
  if FallsLower_DigCave_LeftChest()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_N_SouthMittsCave_LeftChest_B()
  if FallsLower_DigCave_LeftChest()==1 then
    return 1
  else
    return 0
  end
end

function FallsLower_N_SouthMittsCave_RightChest()
  if FallsLower_DigCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_N_SouthMittsCave_RightChest_Y()
  if FallsLower_DigCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_N_SouthMittsCave_RightChest_B()
  if FallsLower_DigCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end
