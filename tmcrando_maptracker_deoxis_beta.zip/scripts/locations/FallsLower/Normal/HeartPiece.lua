function FallsLower_N_HeartPiece_HeartPiece()
  if FallsLower_HP()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_N_HeartPiece_HeartPiece_Y()
  if FallsLower_HP()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_N_HeartPiece_HeartPiece_B()
  if FallsLower_HP()==1 then
    return 1
  else
    return 0
  end
end