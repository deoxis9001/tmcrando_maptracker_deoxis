DirWorld="FallsLower/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."RanchChest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."RanchChest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."Waterfall.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."Waterfall.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."HeartPiece.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."HeartPiece.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."SouthMittsCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."SouthMittsCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. R .."Rupees.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. R .."Rupees.json")
