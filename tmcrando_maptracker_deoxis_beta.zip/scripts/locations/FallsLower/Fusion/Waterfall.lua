function FallsLower_F_Waterfall_Splitblade()
  if FallsLower_WaterfallFusion_DojoNPC()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_F_Waterfall_Splitblade_Y()
  if FallsLower_WaterfallFusion_DojoNPC()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_F_Waterfall_Splitblade_B()
  if FallsLower_WaterfallFusion_DojoNPC()==1 then
    return 1
  else
    return 0
  end
end