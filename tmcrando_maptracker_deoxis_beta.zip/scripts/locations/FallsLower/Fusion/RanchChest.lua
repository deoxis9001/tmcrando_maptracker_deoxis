function FallsLower_F_RanchChest_Chest()
  if FallsLower_LonLonFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_F_RanchChest_Chest_Y()
  if FallsLower_LonLonFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function FallsLower_F_RanchChest_Chest_B()
  if FallsLower_LonLonFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end