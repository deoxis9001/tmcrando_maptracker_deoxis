function Trilby_F_RockChest_Chest()
  if Trilby_MiddleFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_F_RockChest_Chest_Y()
  if Trilby_MiddleFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_F_RockChest_Chest_B()
  if Trilby_MiddleFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end