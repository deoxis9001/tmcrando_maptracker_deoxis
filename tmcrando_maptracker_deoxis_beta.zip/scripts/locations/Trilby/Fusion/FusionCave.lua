function Trilby_F_FusionCave_Chest()
  if Trilby_DigCave_WaterFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_F_FusionCave_Chest_Y()
  if Trilby_DigCave_WaterFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_F_FusionCave_Chest_B()
  if Trilby_DigCave_WaterFusion_Chest()==1 then
    return 1
  else
    return 0
  end
end