DirWorld="Trilby/"

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."FusionCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."FusionCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."NorthernChest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."NorthernChest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. F .."RockChest.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. F .."RockChest.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."BombWall.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."BombWall.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."BusinessScrub.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."BusinessScrub.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. N .."MittsCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. N .."MittsCave.json")

ScriptHost:LoadScript(ScriptLocations..""..DirWorld.."".. R .."RupeeCave.lua")
Tracker:AddLocations(JsLocations..""..DirWorld.."".. R .."RupeeCave.json")
