function Trilby_R_RupeeCave_Rupee()
  if Trilby_PuddleFusion_Item()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_R_RupeeCave_Rupee_Y()
  if Trilby_PuddleFusion_Item()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_R_RupeeCave_Rupee_B()
  if Trilby_PuddleFusion_Item()==1 then
    return 1
  else
    return 0
  end
end