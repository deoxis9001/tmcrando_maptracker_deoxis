function Trilby_N_MittsCave_Chest()
  if Trilby_DigCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_N_MittsCave_Chest_Y()
  if Trilby_DigCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_N_MittsCave_Chest_B()
  if Trilby_DigCave_RightChest()==1 then
    return 1
  else
    return 0
  end
end