function Trilby_N_BombWall_Chest()
  if Trilby_BombCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_N_BombWall_Chest_Y()
  if Trilby_BombCave_Chest()==1 then
    return 1
  else
    return 0
  end
end
function Trilby_N_BombWall_Chest_B()
  if Trilby_BombCave_Chest()==1 then
    return 1
  else
    return 0
  end
end