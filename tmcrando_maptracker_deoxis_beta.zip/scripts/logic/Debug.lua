-- function AccessWestern()
	-- return 1
-- end
function CompleteDeepwood()
	return 0
end