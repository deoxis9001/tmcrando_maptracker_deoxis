
function Smith_House_Chest() 
  return 1
end
function Smith_Floor_Item1() 
  return 1
end
function Smith_Floor_Item2() 
  return 1
end