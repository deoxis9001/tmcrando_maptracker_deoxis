function ToDRightBlock() 
	return 1 
end
function ToDLeftBlock() 
	if ( Tracker:ProviderCountForCode("tod_smallkey") >= 4 ) then
		return 1
	else
		return 0
	end 
end
function ToDBigDoor() 
	if ( has("tod_bigkey") ) then
		return 1
	else
		return 0
	end 
end
function ToDWestDoor() 
	if ( Tracker:ProviderCountForCode("tod_smallkey") >= 4 ) then
		return 1
	else
		return 0
	end 
end
function ToDDarkDoor() 
	if ( Tracker:ProviderCountForCode("tod_smallkey") >= 4 ) then
		return 1
	else
		return 0
	end 
end
function ToDEitherDoor() 
	if ( Tracker:ProviderCountForCode("tod_smallkey") >= 3 ) then
		return 1
	else
		return 0
	end 
end
function ToDChuDoor() 
	if ( Tracker:ProviderCountForCode("tod_smallkey") >= 4 ) then
		return 1
	else
		return 0
	end 
end