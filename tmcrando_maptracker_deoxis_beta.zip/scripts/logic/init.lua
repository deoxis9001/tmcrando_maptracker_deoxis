
ScriptHost:LoadScript("scripts/logic/common.lua")
ScriptHost:LoadScript("scripts/logic/CanDamage.lua")
ScriptHost:LoadScript("scripts/logic/CanSplit.lua")
ScriptHost:LoadScript("scripts/logic/Sword.lua")
ScriptHost:LoadScript("scripts/logic/Beam.lua")
ScriptHost:LoadScript("scripts/logic/NoCloudtop.lua")
ScriptHost:LoadScript("scripts/logic/Elements.lua")
ScriptHost:LoadScript("scripts/logic/Options.lua")
