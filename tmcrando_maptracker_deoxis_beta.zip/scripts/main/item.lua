Tracker:AddItems(JsItems.."common.json")
Tracker:AddItems(JsItems.."dungeon_items.json")
Tracker:AddItems(JsItems.."keys.json")
Tracker:AddItems(JsItems.."options.json")
if(VERSION_BETA==true) then
	Tracker:AddItems(JsItems.."beta.json")
end 