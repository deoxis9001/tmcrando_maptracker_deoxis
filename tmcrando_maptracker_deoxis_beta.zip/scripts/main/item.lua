Tracker:AddItems("items/common.json")
Tracker:AddItems("items/dungeon_items.json")
Tracker:AddItems("items/keys.json")
Tracker:AddItems("items/options.json")
if(VERSION_BETA==true) then
	Tracker:AddItems("items/beta.json")
end 