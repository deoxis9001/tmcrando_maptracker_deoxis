# tmcrando_maptracker_deoxis

---- AUTOTRACKER ----

---- Français ----

Ouvrez Bizhawk.
Allez dans Config -> Customize -> Advanced
Sous Lua Core, cochez l'option pour Lua + LuaInterface.
Allez dans GBA -> Core et assurez-vous que mGBA est sélectionné.
Redémarrez Bizhawk pour appliquer ces modifications.
Allez dans Tools -> Lua Console
Dans la console, allez dans Script -> Open Script
Accédez à l'emplacement où vous avez installé EmoTracker. (C'est C:\Program Files\EmoTracker\Connectors\bizhawk par défaut)
Double-cliquez sur le fichier nommé 'connector'.
Vous devez laisser la console Lua ouverte.
Dans EmoTracker, faites un clic droit sur l'icône du petit robot dans le coin inférieur droit.
Accédez à GBA, puis cliquez sur Lua.
Si vous avez suivi ces instructions, le petit robot devrait devenir cyan.
Apprécier le jeu.

---- English ----

Open Bizhawk.
Go to Config -> Customize -> Advanced
Under Lua Core, check the option for Lua+LuaInterface.
Go to GBA -> Core and make sure mGBA is selected.
Restart Bizhawk to enact these changes.
Go to Tools -> Lua Console
In the console, go to Script -> Open Script
Navigate to where you installed EmoTracker. (This is C:\Program Files\EmoTracker\Connectors\bizhawk by default)
Double click on the file named 'connector'.
You must leave the Lua Console open.
In EmoTracker, right click on the little robot icon in the bottom right corner.
Go to GBA, then click Lua.
If you followed these directions, the little robot should turn cyan.
Enjoy the game.