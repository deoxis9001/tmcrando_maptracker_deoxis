# tmcrando_maptracker_deoxis
----- INSTALATION-------- pour l'utiliser placer les fichiers dans C:\Users__\Documents\EmoTracker\packs et recharger emotracker puis selctionnez le pack

---- AUTOTRACKER--------

Ouvrez Bizhawk.
Allez dans Config -> Customize -> Advanced
Sous Lua Core, cochez l'option pour Lua + LuaInterface.
Allez dans GBA -> Core et assurez-vous que mGBA est sélectionné.
Redémarrez Bizhawk pour appliquer ces modifications.
Allez dans Tools -> Lua Console
Dans la console, allez dans Script -> Open Script
Accédez à l'emplacement où vous avez installé EmoTracker. (C'est C:\Program Files\EmoTracker\Connectors\bizhawk par défaut)
Double-cliquez sur le fichier nommé 'connector'.
Vous devez laisser la console Lua ouverte.
Dans EmoTracker, faites un clic droit sur l'icône du petit robot dans le coin inférieur droit.
Accédez à GBA, puis cliquez sur Lua.
Si vous avez suivi ces instructions, le petit robot devrait devenir cyan.
Apprécier le jeu.